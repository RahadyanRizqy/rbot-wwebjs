service wabot stop
git pull
service wabot restart