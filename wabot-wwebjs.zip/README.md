# R-BOT WhatsappWebJS
Bot ini masih difokuskan untuk hal sticker/gif untuk fitur selanjutnya masih dalam pengerjaan atau orangnya lagi burnout.
## v1.30
- Restrukturisasi message handler
- Restrukturisasi struktur data
- Penambahan fitur epoch