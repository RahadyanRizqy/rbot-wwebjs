// client.on('message', async (msg) => {
//     try {
//         const isGroupMsg = msg.from.endsWith('@g.us') ? true : false;
        
//         const prefix = `${config.prefix}`;
//         if (isOnline) {
//             if (msg.body.startsWith(prefix)) {
//                 const msgBody = msg.body.split(" ");
//                 const command = msgBody[0].split(".")[1];
//                 const argument = msgBody[1] ? (
//                                     msgBody[1].includes(".") ? // IF THERE IS DOT 
//                                         msgBody[1].split(".") : // THEN SPLIT
//                                             msgBody[1] // ELSE GET THE ARGUMENT
//                                                 ) : null; // IF THERE IS NO ARG THEN NULL
//                 if (command === 'sticker') {
//                     if (msg.hasMedia) {
//                         const media = await msg.downloadMedia();
//                         await client.sendMessage(msg.from, 'Loading...');
//                         let stickerAuthor = "";
//                         let stickerName = "";
//                         if (argument !== null) {
//                             if (argument.length === 2) {
//                                 stickerAuthor = `${(argument[1].includes("_") ? argument[1].split("_").join(" ") : argument[1])} • ${config.author}`;
//                                 stickerName = argument[0].includes("_") ? argument[0].split("_").join(" ") : argument[0];
//                             } else if (argument.length){
//                                 stickerAuthor = `${config.author}`;
//                                 stickerName = argument.includes("_") ? argument.split("_").join(" ") : argument;
//                             }                            
//                         }
//                         else {
//                             stickerAuthor = `${config.author}`;
//                             stickerName = `${config.name}`;
//                         }
//                         await client.sendMessage(msg.from, media, {
//                             sendMediaAsSticker: true,
//                             stickerName: stickerName,
//                             stickerAuthor: stickerAuthor
//                         });
//                         await msg.delete();
//                     }
//                     else {
//                         await client.sendMessage(msg.from, 'Media tidak dicantumkan!');
//                     }
//                 }
//                 else if (command === 'about') {
//                     let adminProfile = null;
//                     if (fileExists('./statics/admin.jpg')) {
//                         adminProfile = MessageMedia.fromFilePath('./statics/admin.jpg');
//                     } else {
//                         adminProfile = await MessageMedia.fromUrl('https://fastly.picsum.photos/id/866/300/300.jpg?hmac=9qmLpcaT9TgKd6PD37aZJZ_7QvgrVFMcvI3JQKWVUIQ');
//                     }
//                     const userName = (await msg.getContact()).pushname;
//                     await client.sendMessage(msg.from, adminProfile, {
//                         caption: `${aboutCaption(userName) ?? 'your about'}`
//                     });
//                 }
//                 else if (command === 'help') {
//                     await client.sendMessage(msg.from, `${helpMsg(prefix) ?? 'your help message'}`);
//                 }
//                 else if (command === 'greet') {
//                     // client.sendMessage(msg.from, `@${contact.id.user}`, { mentions: [contact]}); TAG A USER
//                     await client.sendMessage(msg.from, `Halo 👋 ${(await msg.getContact()).pushname}`);
//                 }
//                 else if (command === 'epoch') {
//                     const currentTime = Date.now();
//                     if (argument) {
//                         const [day, month, year] = argument[0] ? argument[0].split('-').map(Number) : null;
//                         const [hours, minutes, seconds] = argument[1] ? argument[1].split(':').map(Number) : '00:00:00'.split(':').map(Number);
//                         const dateObject = new Date(year, month - 1, day, hours, minutes, seconds);
//                         if (dateObject.getTime().toString().includes('-')) {
//                             await client.sendMessage(msg.from, "Tanggal tidak valid (format: DD-MM-YYYY.HH:MM:SS)");
//                         } else {
//                             await client.sendMessage(msg.from, `${dateObject.getTime()}`);
//                         }
//                     }
//                     else {
//                         await client.sendMessage(msg.from, `${currentTime}`);
//                     }
//                 }
//                 else if (command === 'feature') {
//                     await client.sendMessage(msg.from, `${featureMsg}`);
//                 }
//                 else if (command === 'igdl') {
//                     async function getLinksFromInstagram(url) {
//                         try {
//                             const browser = await puppeteer.launch({ headless: true });
//                             const page = await browser.newPage();
//                             await page.goto('https://ngopinsta.vercel.app');
//                             await page.type('input[name="url"]', url);
//                             await page.click('button[aria-label="Button Download"]');
//                             await page.waitForSelector('button[aria-label="button download more"]');
//                             await page.waitForSelector('main.container.relative.flex-grow.h-full.mx-auto.mt-16');
//                             const childNodes = await page.evaluate(() => {
//                                 const mainSelector = 'main.container.relative.flex-grow.h-full.mx-auto.mt-16';
//                                 const mainElement = document.querySelector(mainSelector).children[1];
//                                 if (!mainElement) return [];
//                                 const mainElementChildren =  mainElement.children;
//                                 let links = [];
//                                 for (let i = 0; i < mainElementChildren.length; i++) {
//                                     const parser = new DOMParser();
//                                     const doc = parser.parseFromString(mainElementChildren[i].children[1].children[2].innerHTML, 'text/html'); // relative-overflow
//                                     const anchorElement = doc.querySelector('a');
//                                     if (anchorElement) { links.push(anchorElement.getAttribute('href')); }
//                                 }
//                                 return links;
//                             });
//                             await browser.close();
//                             return childNodes;
//                         } catch (error) {
//                             console.error('Error:', error);
//                             return [];
//                         }
//                     }
//                     if (msgBody[1] === undefined) {
//                         await client.sendMessage(msg.from, "Tidak ada link...");
//                     } else {
//                         // await client.sendMessage(msg.from, `${msgBody[1]}`);
//                         try {
//                             const mediaUrls = await getLinksFromInstagram(msgBody[1]);
//                             if (mediaUrls.length > 1) {
//                                 for (let i = 0; i < mediaUrls.length; i++) {
//                                     const content = await MessageMedia.fromUrl(`${mediaUrls[i]}`, { unsafeMime: true });
//                                     await client.sendMessage(msg.from, content);
//                                 }
//                                 // await client.sendMessage(msg.from, `${mediaUrls.length}`);
//                             }
//                             else if (mediaUrls.length === 1) {
//                                 const content = await MessageMedia.fromUrl(`${mediaUrls[0]}`, { unsafeMime: true });
//                                 await client.sendMessage(msg.from, content);
//                             }
//                             else {
//                                 await client.sendMessage(msg.from, 'Pastikan link bisa diakses secara publik! Jika publik, ulangi lagi');
//                             }
//                         }
//                         catch (error) {
//                             console.log(error);
//                             logErrorToFile(error.toString());
//                             await client.sendMessage(msg.from, 'Pastikan link bisa diakses secara publik! Jika publik, ulangi lagi');
//                         }
//                     }
//                 }
//                 else if (command === 'halt' && msg.from === '6288804897436@c.us') { // ADMIN ONLY COMMAND
//                     await client.sendMessage(msg.from, '[BOT-HALTED]');
//                     isOnline = false;
//                     isInMaintenance = true;
//                     await client.setStatus(maintenanceMsg);
//                 }
//                 else {
//                     await client.sendMessage(msg.from, 'Command tidak tersedia. Silahkan *.help*');
//                 }
//             }
//             else if (msg.body.toLocaleLowerCase() === 'p' || (msg.body.toLocaleLowerCase()[0] === 'p' && /(.)\1+/.test(msg.body.toLocaleLowerCase()))) {
//                 await client.sendMessage(msg.from, 'Apa cuk, pa pe pa pe, yang sopan! 😑 *.help*')
//             }
//             else if (msg.body.toLocaleLowerCase().includes('assalamualaikum')) {
//                 await client.sendMessage(msg.from, 'Waalaikumussalam 😇🙏')
//             }
//             else {
//                 await client.sendMessage(msg.from, 'Tidak jelas, mangsud? 🤨 *.help*');
//             }

//         } else if (isInMaintenance) {
//             if (msg.body === '.on' && msg.from === '6288804897436@c.us') { // ADMIN ONLY COMMAND
//                 await client.sendMessage(msg.from, '[BOT-ONLINE]');
//                 isOnline = true;
//                 isInMaintenance = false;
//                 await client.setStatus(onlineMsg);
//             } else if (msg.body === '.off' && msg.from === '6288804897436@c.us') {
//                 await client.sendMessage(msg.from, '[BOT-OFFLINE]');
//                 isOnline = false;
//                 isInMaintenance = false;
//                 isOffline = true;
//                 await client.setStatus(offlineMsg);
//             } else {
//                 await client.sendMessage(msg.from, 'Sedang maintenance mohon bersabar 😗');
//             }
//         } else {
//             await client.sendMessage(msg.from, 'Segera offline...');
//         }
//     }
//     catch (error) {
//         console.log(error);
//         logErrorToFile(error.toString());
//         await client.sendMessage(msg.from, 'Ada error! 😵‍💫');
//         // status = 'Terjadi error!';
//         await client.setStatus('Terjadi error!');
//     }
// });

const date = require('date-and-time');

const now = new Date();

date.format(now, 'YYYY/MM/DD HH:mm:ss'); 
console.log(date.format(new Date(), 'YYYY/MM/DD HH:mm:ss'));